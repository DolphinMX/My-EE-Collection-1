/*
Conversion formula from Fahrenheit to Celious
C=(F-32)*5/9;
*/
#include<iostream>
using namespace std;

int main() {
	double C = 0;
	double F = 0;
	double factor;

	cout << "Input temperature in Fahrenheit:";
	cin >> F;
	factor = 5 / 9;
	C = (F - 32) * factor;
	cout << "Temperature in Celius: " << C << endl;
	return 0;
}
