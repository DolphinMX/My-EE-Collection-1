#include <iostream>
using namespace std;

void hello(int age) {
	cout << "Hello, "; //try "Shift F11" to step out the function on second time.
	cout << "I am "<< age <<" years old" <<endl;
}

int main() {
	hello(10);
	hello(20); // press F11 to step into the function
	hello(15); // call hello the third time
	return 0;
}
