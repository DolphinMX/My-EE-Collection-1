#include<iostream>
using namespace std;
int main() {
	int x;
	x = 3;
	cin >> x;
	cout << x;
	return 0;
}
