/*debug the following program which sum all the elements for array n*/

#include <iostream>
using namespace std;

int main(){
	int n[3] = {5, 10, 5};
	int sum, i = 0;
	while(i <= 3){
		i++;
		sum += n[i];
	}
	cout << sum <<endl;
	return 0;
}
