#include <iostream>
using namespace std;
int main() {
	int no_of_rows = 6;
	int row;
	int num_count;
	int num;

	for(row = 0; row < no_of_rows; row++) {
		num_count = 0;
		for(; num_count <= row; num_count++){
			num = 6 - num_count;
			cout << num;
		}
		cout << endl;
	}
	return 0;
}
