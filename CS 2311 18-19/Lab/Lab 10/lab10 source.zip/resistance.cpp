#include <iostream>
#include <iomanip>
using namespace std;

void getInput( /* Write the parameters here */ ) {
	
	cout << "Please enter two values: ";
	
	//TODO: read voltage and current and pass them back using call by reference
}

double toResistance( /* Write the parameters here */ ) {
	
	//TODO return the resistance based on the voltage and current
}

void swap( /* Write the parameters here */ ) {
	//TODO swap the values of V and I using call by reference
}

void main(){
	double voltage, resistance;
	
	getInput(/* Write the parameters here */);
	cout << "The value of one resistance is ";
	cout << fixed << setprecision(2) << toResistance(/* Write the parameters here */) << endl;
	
	swap(/* Write the parameters here */);
	
	cout << "The value of the other resistance is ";
	cout << fixed << setprecision(2) << toResistance(/* Write the parameters here */) << endl;
}


