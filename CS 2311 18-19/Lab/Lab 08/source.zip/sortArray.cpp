#include <iostream>

using namespace std;
const int N = 10;

// TODO 1: Complete the function declaration, which
//        takes 2 integers using pass-by-reference
void Swap() {
    // TODO2: Complete the function of Swap
    //       you may declare local variables if needed
}


int main() {
    int Num[N];
    int i, j;

    cout << "Enter "<< N << " numbers:"<<endl;
    for (i = 0; i < N; i++)
        cin >> Num[i];


    // TODO3: Fill in the indexes of the 2 for-loop so
    //       as to sort numbers in ascending order
    for (i =;; i++) {
        for (j =;; j++) {
            if (Num[j] Num[]) {  // TODO4: Fill in the index and relational operator
                Swap(Num[j], Num[]);
            }
        }
    }

    cout << "The sorted numbers:\n";

    for (i = 0; i < N; i++) {
        cout << Num[i] << " ";
    }
    cout << endl;

    return 0;
}
