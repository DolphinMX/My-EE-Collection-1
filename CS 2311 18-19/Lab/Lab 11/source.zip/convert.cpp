#include <iostream>
#include <cstring>

using namespace std;

int main() {
	char c, inWord[50], outWord[50];
	int j = 0;

	// Add your code here to read a string that may contain multiple words


	//Add your logic here to check for and to convert to uppercases



	//How to mark the end of outWord here?
	//(user input may be less than 50 chars)

	cout << outWord;
	return 0;
}
