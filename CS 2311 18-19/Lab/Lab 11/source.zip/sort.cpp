#include <iostream>
#include <cstring>

using namespace std;

void strexchg(const char **m1, const char **m2) {
    // TODO: swap the values of m1 and m2 using call by reference
}

int main() {
    const int N = 6;
    const char *course[] = {"Mathematics", "English", "Data structures", "C++ Programming", "Internet",
                            "Java Programming"};

    // TODO: sort the array in an ascending alphabetical order

    for (i = 0; i < N; i++)
        cout << course[i] << endl;

    return 0;
}
